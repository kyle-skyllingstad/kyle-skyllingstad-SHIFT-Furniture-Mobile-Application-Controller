//
//  ViewController6.swift
//  SHIFT Furniture MOBILE APPLICATION
//  Created by Kyle Skyllingstad
//

// Import necessary kits
import UIKit

// Class for screen 7, ViewController7 (unused currently, used for testing and modification purposes)
class ViewController7: UIViewController {

    
    // Main test screen loading function
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    


}
